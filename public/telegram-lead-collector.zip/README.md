# Telegram Lead Collector — MVP (Chrome MV3)

Détecte et collecte **localement** les liens `t.me` visibles pendant la navigation
sur **Instagram**, **TikTok**, **Twitter/X**, **Taplink**, **Beacons**, **Linktree** et **taap.it**,
ainsi qu'à la **copie (Ctrl+C)** sur Instagram/Twitter/TikTok/Telegram Web, et par **ajout manuel** depuis le popup. Export CSV.

## Caractéristiques
- **Manifest V3**, permissions minimales (`storage` + hosts Instagram/TikTok).
- **Lecture seule** du DOM déjà affiché (anchors `a[href]` + texte visible).
- Détection temps réel via **MutationObserver** + scan initial + re-scan léger (SPA).
- **Déduplication stricte** par URL exacte (les URLs ne sont jamais modifiées).
- **100% offline** : aucune API externe, aucun backend, tout dans `chrome.storage.local`.
- Popup : compteur, **Export CSV**, **Copier CSV**, **Clear data**, toggle *surlignage + compteur overlay*.

## Données collectées (par lead)
```json
{
  "url": "",
  "platform": "instagram | tiktok",
  "source_url": "",
  "context_text": "",
  "timestamp": "",
  "placement": "bio | caption | comment | story"
}
```
CSV exporté : `url,platform,source_url,timestamp,placement`

## Installation (Load unpacked)
1. Chrome → `chrome://extensions/`
2. Activer **Mode développeur** (haut droite)
3. **Charger l'extension non empaquetée** → sélectionner le dossier `telegram-lead-collector/`
4. Naviguer sur Instagram / TikTok et scroller : les liens `t.me` sont collectés automatiquement.
5. Cliquer l'icône de l'extension → **Export CSV**.

## Fichiers
- `manifest.json` — déclaration MV3
- `content.js` — détection/scraping DOM (MutationObserver, debounce)
- `background.js` — service worker : stockage + dédup + badge
- `popup.html` / `popup.js` — interface (compteur, export, clear, toggle)

## Note d'usage responsable
L'extension lit uniquement des liens **publics** déjà affichés dans votre propre
navigateur, et ne transmet rien à l'extérieur. L'utilisation de données collectées
(prospection, etc.) doit respecter les CGU d'Instagram/TikTok, le RGPD et les
règles du Chrome Web Store. Pas d'icône fournie (Chrome utilise une icône par
défaut) — ajoutez `icons` au manifest si besoin pour la publication.
