/* Telegram Lead Collector — background service worker (MV3)
 * Stockage local centralisé + déduplication stricte par URL exacte.
 * Aucune connexion réseau. Tout reste dans chrome.storage.local.
 */
"use strict";

const STORE_KEY = "tlc_leads";

function getLeads() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORE_KEY], (s) => resolve((s && s[STORE_KEY]) || []));
  });
}

function setLeads(leads) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [STORE_KEY]: leads }, () => resolve());
  });
}

async function addLeads(incoming) {
  const leads = await getLeads();
  const index = new Set(leads.map((l) => l.url)); // clé = URL exacte
  let added = 0;
  for (const lead of incoming || []) {
    if (!lead || !lead.url) continue;
    if (index.has(lead.url)) continue; // dédup stricte
    index.add(lead.url);
    leads.push(lead);
    added++;
  }
  if (added) await setLeads(leads);
  return { count: leads.length, added };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === "ADD_LEADS") {
    addLeads(msg.leads).then((r) => {
      updateActionBadge(r.count);
      sendResponse(r);
    });
    return true; // réponse asynchrone
  }

  if (msg.type === "GET_LEADS") {
    getLeads().then((leads) => sendResponse({ leads, count: leads.length }));
    return true;
  }

  if (msg.type === "CLEAR_LEADS") {
    setLeads([]).then(() => {
      updateActionBadge(0);
      sendResponse({ ok: true });
    });
    return true;
  }
});

function updateActionBadge(count) {
  try {
    chrome.action.setBadgeBackgroundColor({ color: "#2ea6ff" });
    chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
  } catch (_) {}
}

// Initialise le badge au démarrage du worker
getLeads().then((leads) => updateActionBadge(leads.length));
