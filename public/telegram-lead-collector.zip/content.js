/* Telegram Lead Collector — content script
 * Détecte les liens t.me visibles (anchors + texte) sur Instagram / TikTok,
 * en temps réel pendant le scroll (MutationObserver + scan initial).
 * Lecture seule du DOM déjà affiché. Aucune donnée n'est envoyée à l'extérieur.
 */
(() => {
  "use strict";

  const PLATFORM = location.hostname.includes("tiktok") ? "tiktok" : "instagram";

  // Capture toute URL contenant t.me (http(s):// optionnel), sans la modifier.
  const TME_RE = /((?:https?:\/\/)?t\.me\/[^\s"'<>)\]}]+)/gi;

  const seen = new Set();        // urls déjà envoyées cette session (anti-spam messages)
  let queue = [];                // leads en attente d'envoi (batch)
  let highlight = false;         // surlignage activé ?

  // --------------------------------------------------------------------
  // Helpers
  // --------------------------------------------------------------------
  function cleanText(s) {
    return (s || "").replace(/\s+/g, " ").trim().slice(0, 160);
  }

  // Devine l'emplacement (bio / caption / comment / story) au mieux.
  function guessPlacement(el) {
    let node = el;
    for (let i = 0; node && i < 12; i++, node = node.parentElement) {
      const tag = (node.tagName || "").toLowerCase();
      const role = (node.getAttribute && node.getAttribute("role")) || "";
      const cls = (node.className && typeof node.className === "string" ? node.className : "").toLowerCase();
      const aria = ((node.getAttribute && node.getAttribute("aria-label")) || "").toLowerCase();

      if (tag === "header" || aria.includes("bio") || cls.includes("bio")) return "bio";
      if (role === "dialog" && (aria.includes("comment") || cls.includes("comment"))) return "comment";
      if (cls.includes("comment") || aria.includes("comment")) return "comment";
      if (aria.includes("story") || aria.includes("stories") || cls.includes("story")) return "story";
      if (tag === "article" || cls.includes("caption")) return "caption";
    }
    // Heuristique de repli : haut de page = bio (profil), sinon caption.
    try {
      const top = el.getBoundingClientRect().top + window.scrollY;
      if (top < 600) return "bio";
    } catch (_) {}
    return "caption";
  }

  function pushLead(url, el, contextText) {
    if (!url || seen.has(url)) return;
    seen.add(url);
    queue.push({
      url: url,                                  // URL exacte, non modifiée
      platform: PLATFORM,
      source_url: location.href,
      context_text: cleanText(contextText),
      timestamp: new Date().toISOString(),
      placement: el ? guessPlacement(el) : "page",
    });
    if (highlight && el && el.tagName === "A") {
      el.style.outline = "2px solid #2ea6ff";
      el.style.outlineOffset = "1px";
    }
  }

  // --------------------------------------------------------------------
  // Scan
  // --------------------------------------------------------------------
  function scanElement(root) {
    if (!root || root.nodeType !== 1) return;

    // 1) Liens <a href>
    const anchors = [];
    if (root.tagName === "A") anchors.push(root);
    if (root.querySelectorAll) {
      root.querySelectorAll("a[href]").forEach((a) => anchors.push(a));
    }
    for (const a of anchors) {
      const href = a.getAttribute("href") || a.href || "";
      const m = href.match(TME_RE);
      if (m) m.forEach((u) => pushLead(u, a, a.textContent || a.closest("*")?.textContent));
    }

    // 2) Texte visible (bio/caption/comment qui contiennent un t.me en clair)
    const text = root.innerText;
    if (text && text.indexOf("t.me/") !== -1) {
      let mm;
      TME_RE.lastIndex = 0;
      while ((mm = TME_RE.exec(text)) !== null) {
        pushLead(mm[1], root, text);
      }
    }
  }

  function fullScan() {
    scanElement(document.body);
    flush();
  }

  // --------------------------------------------------------------------
  // Envoi par lots (vers background pour stockage + dédup global)
  // --------------------------------------------------------------------
  function flush() {
    if (!queue.length) return;
    const batch = queue;
    queue = [];
    try {
      chrome.runtime.sendMessage({ type: "ADD_LEADS", leads: batch }, (res) => {
        if (chrome.runtime.lastError) return; // contexte invalidé : on ignore
        if (res && typeof res.count === "number") updateBadge(res.count);
      });
    } catch (_) {}
  }

  // --------------------------------------------------------------------
  // Overlay compteur (optionnel, visible si highlight activé)
  // --------------------------------------------------------------------
  let overlay;
  function updateBadge(count) {
    if (!highlight) {
      if (overlay) overlay.style.display = "none";
      return;
    }
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "tlc-overlay";
      Object.assign(overlay.style, {
        position: "fixed", bottom: "16px", right: "16px", zIndex: 2147483647,
        background: "rgba(15,20,28,0.92)", color: "#cfe3ff",
        font: "600 12px/1 -apple-system,Segoe UI,sans-serif",
        padding: "8px 12px", borderRadius: "999px",
        border: "1px solid rgba(46,166,255,0.5)", pointerEvents: "none",
      });
      document.documentElement.appendChild(overlay);
    }
    overlay.style.display = "block";
    overlay.textContent = "📡 " + count + " leads Telegram";
  }

  // --------------------------------------------------------------------
  // MutationObserver (debounce)
  // --------------------------------------------------------------------
  let pending = [];
  let timer = null;
  function schedule() {
    if (timer) return;
    timer = setTimeout(() => {
      timer = null;
      const nodes = pending;
      pending = [];
      for (const n of nodes) {
        if (n.nodeType === 1) scanElement(n);
        else if (n.nodeType === 3 && n.parentElement) scanElement(n.parentElement);
      }
      flush();
    }, 400);
  }

  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      m.addedNodes && m.addedNodes.forEach((n) => pending.push(n));
      if (m.type === "characterData" && m.target) pending.push(m.target);
    }
    schedule();
  });

  // --------------------------------------------------------------------
  // Init
  // --------------------------------------------------------------------
  chrome.storage.local.get(["tlc_highlight"], (s) => {
    highlight = !!(s && s.tlc_highlight);
    fullScan();
    observer.observe(document.documentElement, {
      childList: true, subtree: true, characterData: true,
    });
  });

  // Re-scan périodique léger (apps SPA qui réécrivent le DOM)
  setInterval(fullScan, 4000);

  // Réagit au toggle highlight depuis le popup
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.tlc_highlight) {
      highlight = !!changes.tlc_highlight.newValue;
      if (!highlight && overlay) overlay.style.display = "none";
    }
  });
})();
