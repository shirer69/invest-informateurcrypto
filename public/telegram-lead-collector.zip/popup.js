/* Telegram Lead Collector — popup logic */
"use strict";

const $ = (id) => document.getElementById(id);
const msg = (t) => { $("msg").textContent = t || ""; };

function send(type, extra) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(Object.assign({ type }, extra || {}), (r) => resolve(r || {}));
  });
}

function csvEscape(v) {
  const s = String(v == null ? "" : v);
  return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function toCSV(leads) {
  const header = "url,platform,source_url,timestamp,placement";
  const rows = leads.map((l) =>
    [l.url, l.platform, l.source_url, l.timestamp, l.placement].map(csvEscape).join(",")
  );
  return [header].concat(rows).join("\n");
}

async function refresh() {
  const { leads, count } = await send("GET_LEADS");
  $("count").textContent = count || 0;
  return leads || [];
}

function download(filename, text) {
  const blob = new Blob([text], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

$("export").addEventListener("click", async () => {
  const leads = await refresh();
  if (!leads.length) return msg("Aucun lead à exporter.");
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  download(`telegram-leads-${stamp}.csv`, toCSV(leads));
  msg(`${leads.length} leads exportés.`);
});

$("copy").addEventListener("click", async () => {
  const leads = await refresh();
  if (!leads.length) return msg("Aucun lead à copier.");
  try {
    await navigator.clipboard.writeText(toCSV(leads));
    msg("CSV copié dans le presse-papiers.");
  } catch (_) {
    msg("Copie impossible (autorisez le presse-papiers).");
  }
});

async function addManual() {
  const url = $("manualUrl").value.trim();
  if (!url) return;
  const lead = {
    url: url,                       // URL exacte, non modifiée
    platform: "manual",
    source_url: "manual",
    context_text: "Ajout manuel",
    timestamp: new Date().toISOString(),
    placement: "manual",
  };
  const r = await send("ADD_LEADS", { leads: [lead] });
  $("manualUrl").value = "";
  await refresh();
  msg(r && r.added ? "URL ajoutée." : "Déjà présente.");
}
$("add").addEventListener("click", addManual);
$("manualUrl").addEventListener("keydown", (e) => { if (e.key === "Enter") addManual(); });

$("clear").addEventListener("click", async () => {
  if (!confirm("Supprimer tous les leads collectés ?")) return;
  await send("CLEAR_LEADS");
  await refresh();
  msg("Données effacées.");
});

$("hl").addEventListener("change", (e) => {
  chrome.storage.local.set({ tlc_highlight: e.target.checked });
  msg(e.target.checked ? "Surlignage activé (recharge la page)." : "Surlignage désactivé.");
});

// Init
chrome.storage.local.get(["tlc_highlight"], (s) => {
  $("hl").checked = !!(s && s.tlc_highlight);
});
refresh();
